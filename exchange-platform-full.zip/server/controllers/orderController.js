
const Order = require('../models/Order');

exports.createOrder = async (req, res) => {
  const { fromMethod, toMethod, amount, phone, note, targetAddress } = req.body;
  const receiptImage = req.file?.filename || '';
  const order = new Order({
    user: req.user.id,
    fromMethod,
    toMethod,
    amount,
    phone,
    note,
    targetAddress,
    receiptImage
  });
  await order.save();
  res.status(201).json({ message: 'Order created', order });
};

exports.getUserOrders = async (req, res) => {
  const orders = await Order.find({ user: req.user.id });
  res.json(orders);
};

exports.getAllOrders = async (req, res) => {
  if (!req.user.isAdmin) return res.sendStatus(403);
  const orders = await Order.find().populate('user', 'username');
  res.json(orders);
};

exports.updateOrderStatus = async (req, res) => {
  if (!req.user.isAdmin) return res.sendStatus(403);
  const { status } = req.body;
  const order = await Order.findByIdAndUpdate(req.params.id, { status }, { new: true });
  res.json(order);
};
