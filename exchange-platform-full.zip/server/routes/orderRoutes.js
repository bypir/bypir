
const express = require('express');
const router = express.Router();
const multer = require('multer');
const { createOrder, getUserOrders, getAllOrders, updateOrderStatus } = require('../controllers/orderController');
const auth = require('../middleware/authMiddleware');

const upload = multer({ dest: 'uploads/' });

router.post('/', auth, upload.single('receipt'), createOrder);
router.get('/', auth, getUserOrders);
router.get('/admin', auth, getAllOrders);
router.put('/:id/status', auth, updateOrderStatus);

module.exports = router;
